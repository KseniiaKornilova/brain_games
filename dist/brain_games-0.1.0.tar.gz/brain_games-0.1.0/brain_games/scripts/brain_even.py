#!/usr/bin/env python3
from .. import even_logic

def main():
    even_logic.even()
    
    
if __name__ == '__main__':
    main()

