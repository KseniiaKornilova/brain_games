# brain_games
<a href="https://codeclimate.com/github/KseniiaKornilova/brain_games/maintainability"><img src="https://api.codeclimate.com/v1/badges/f5f72597e25a7bdbf84c/maintainability" /></a>

